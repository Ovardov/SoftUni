const authCookieName = 'auth_cookie';
const secret = 'secret';

module.exports = {
    authCookieName,
    secret
}