const userModel = require('./User');
const expenseModel = require('./Expense');

module.exports = {
    userModel,
    expenseModel
}
